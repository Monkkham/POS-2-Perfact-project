<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AssetManagement\\Providers\\AssetManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AssetManagement\\Providers\\AssetManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);